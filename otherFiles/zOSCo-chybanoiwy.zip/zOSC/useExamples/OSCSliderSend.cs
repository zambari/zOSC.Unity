﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityOSC;
// zOSC use example

public class OSCSliderSend : MonoBehaviour
{
    // [Header("MODDED VERSION UWAGA")]
    public string OSCName;
    public Slider slider;
    public Text valueDisplayText;
    public bool sendAsInt;
    public int parameterRepeatCount = 1;
    void OnValidate()
    {
        if (slider == null) slider = GetComponent<Slider>();
        OSCName = zOSC.SanitizeAddress(OSCName);
        if (valueDisplayText == null) valueDisplayText = GetComponentInChildren<Text>();
    }

    void Start()
    {
        slider.onValueChanged.AddListener(newSliderValue);
        if (sendAsInt)
            zOSC.Bind(this,OSCName, RecieveFloat );
        // else 
        // zOSC.bind(this,RecieveFloat,OSCName);
    }

    void Recieveint(int i)
    {
        Debug.Log("Recieved " + i);
    }
    void RecieveFloat(float i)
    {
        Debug.Log("Recieved " + i);
    }

    public bool sendmax;
    public bool negative;
    void newSliderValue(float f)
    {
        //z
        if (sendAsInt)
        {
            System.Int32 val = (System.Int32)(f * (negative ? -1 : 1) * (sendmax ? System.Int32.MaxValue : 10000));
            //    System.Int32 val = (System.Int32)(f *100);
            Debug.Log("sent " + val);
            OSCMessage msg = new OSCMessage(OSCName);
            for (int i = 0; i < parameterRepeatCount; i++)
                msg.Append(val);

            zOSC.BroadcastOSC(msg);
            //zOSC.BroadcastOSC(OSCName, val);
        }
        else
        {
            zOSC.BroadcastOSC(OSCName, f);
        }

        if (valueDisplayText != null) valueDisplayText.text = (Mathf.Round(f * 10) / 10).ToString();
    }

}
