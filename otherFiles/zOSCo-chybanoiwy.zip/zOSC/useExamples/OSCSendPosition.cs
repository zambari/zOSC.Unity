﻿///zambari codes unity

using UnityEngine;
//using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;

public class OSCSendPosition : MonoBehaviour {
public string Address;
Vector3 lastPos;
void Update()
{
if (transform.position!=lastPos)
{lastPos=transform.position;
zOSC.BroadcastOSC(Address,lastPos);
}

}
	
}
