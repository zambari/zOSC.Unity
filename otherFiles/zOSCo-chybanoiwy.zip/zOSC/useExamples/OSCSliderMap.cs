﻿///zambari codes unity

using UnityEngine;
using UnityEngine.UI;

//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;

public class OSCSliderMap : OSCBindBasic
{
    Slider slider;
    public Slider shadowSlider;

    void Awake()
    {
        slider = GetComponent<Slider>();
        slider.onValueChanged.AddListener(SendOnSliderMove);

    }
    public bool send;
    public bool recieve = true;
    void SendOnSliderMove(float f)
    {
        if (send)
            zOSC.BroadcastOSC(OSCAddress, f);

    }

    void OnRecieveOsc(float f)
    {
        if (recieve)
        {
            if (shadowSlider != null)
                shadowSlider.value = f;
            else
                slider.value = f;
        }

    }
    protected override void OSCBind()
    {
        zOSC.Bind(this,OSCAddress, OnRecieveOsc );

    }


}
