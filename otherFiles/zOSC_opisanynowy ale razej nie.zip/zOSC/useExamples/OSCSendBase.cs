﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OSCSendBase : MonoBehaviour {

	public string OSCAddress="/adr";
}
