﻿///zambari codes unity



/*




                disabled <--->  idle  <---> hovered
                                  ^ \
                                  |  \
                                  |    pressed ---->  selected    <---> hovered
                                  |                      /   
                                  |                     /  
                                 pressed  <------      /

*/


using UnityEngine;
using UnityEngine.UI;

public class zUIState  {
 public zColorProvider colorProvider;
 //public Image targetImage;
  public enum States { idle, hover, pressed, selected, selectedHover,inactive }

//bool isHovered;
bool isSelected;
bool isDisabled;
public States currentState;

//[HideInInspector]
public Color currentColor;

/*
void OnValidate()
{
if (colorProvider==null) colorProvider=GetComponentInParent<zColorProvider>();
if (targetImage==null) targetImage=GetComponentInChildren<Image>();

}*/


/*void Init()
{
if (colorProvider==null)

}*/

public void enable()
{
 isDisabled=false;


}
public void disable()
{
    isDisabled=true;
}

public void hoverExit()
{
    if (isDisabled) return;
  ///currentColor = 
}

public void hoverEnter()
{
  if (isDisabled) return;

    if (currentState==States.idle) 

     {
      // isHovered=true;
       
       
        }
    }


}




