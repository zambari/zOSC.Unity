﻿///zambari codes unity

using System;
using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;

public class HierarchyTransformDisplay : InspectorBase {
    
public InputField x;
public InputField y;
public InputField z;

public InputField sx;
public InputField sy;
public InputField sz;
	Transform source;
    public  override void linktToComponent(Component thisComponent) {
     Transform sourceTransform=(Transform)thisComponent;
    
      source=sourceTransform;
      updateTransformDisplay();
      name="INSP Transform";

    }
public void onInputfieldChange()
{
    /*/
Debug.Log("tryingf pos "+
   source.localPosition=new Vector3(Single.Parse(x.text),
                        Single.Parse(y.text),Single.Parse(z.text));
*/
}

    void updateTransformDisplay()
    {

        x.text=source.position.x.ToString();
        x.text=source.position.y.ToString();
        x.text=source.position.z.ToString();

        sx.text=source.localScale.x.ToString();
        sx.text=source.localScale.y.ToString();
        sx.text=source.localScale.z.ToString();
        

    }
}
