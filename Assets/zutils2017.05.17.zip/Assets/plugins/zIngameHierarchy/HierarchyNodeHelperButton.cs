﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class HierarchyNodeHelperButton : MonoBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{

    public HierarchyNode parentNode;
    Image image;
    public Color nonHoveredColor = new Color(1, 1, 1, 0.1f);
    public Color hoveredColor = new Color(1, 1, 1, 0.3f);
    public Color disabledFlash = new Color(1, 1, 1, 0.3f);
    Text text;
    public enum Modes {main,  inspect, toggleActive ,expand}
    [SerializeField]
    public Modes mode;
    // Update is called once per frame
    void Start()
    {
        image = GetComponent<Image>();
        text = GetComponentInChildren<Text>();
    }
void setColor()
{
            image.color = nonHoveredColor;
}
    public void OnPointerClick(PointerEventData eventData)
    {
        if (parentNode.isDisabled)
        {
            image.color=nonHoveredColor*2;
            Invoke("setColor",0.2f);
            return;
        }
        if (mode == Modes.main)
            parentNode.OnClick();
	else  if (mode == Modes.expand)
            parentNode.OnClick();
	else
	    if (mode == Modes.inspect)
            parentNode.Inspect();
        else
       if (mode == Modes.toggleActive)
        {
            bool active = parentNode.referencedGameObject.activeSelf;
            text.text = (active ? "X" : "A  ");
            parentNode.setGameObjectActiveState(!active);
        }
        eventData.Use();
    }
    void OnValidate()
    {
        image = GetComponent<Image>();
        image.color = nonHoveredColor;
    }



    public void OnPointerEnter(PointerEventData eventData)
    {

        image.color = hoveredColor;
        eventData.Use();
    }
    public void OnPointerExit(PointerEventData eventData)
    {
        image.color = nonHoveredColor;
//        Debug.Log("hov");
        eventData.Use();
    }
}
