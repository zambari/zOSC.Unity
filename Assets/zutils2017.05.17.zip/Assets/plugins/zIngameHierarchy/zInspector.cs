﻿///zambari codes unity

using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
using System.Collections.Generic;


public class zInspector : zNodeController
{

    //   public HierarchyTransformDisplay showTransform;
    //   public Button componentHeaderTemplate;
    //public Transform contentDestination;
    public HierarchyInspectorLoader genericComponentLoader;
   // public GameObject templates;
    //public FloatRangedInspector floatTemplate;
    GameObject editedGameObject;
  //  public Text objectLabel;
    protected override void Start()
    {
        base.Start();
     //   templates.SetActive(false);
    }

    public void focusOn(GameObject referencedGameObject)
    {

        for (int i = content.transform.childCount - 1; i >= 0; i--)
        {
            Destroy(content.transform.GetChild(i).gameObject);
        }


        editedGameObject = referencedGameObject;
        text.text = editedGameObject.name;

        //  showTransform.showTransform(referencedGameObject.transform);
        Component[] allComponents = referencedGameObject.GetComponents<Component>();

        for (int i = 0; i < allComponents.Length; i++)
        {
            //    Button newHeader=Instantiate(componentHeaderTemplate,contentDestination);
            HierarchyInspectorLoader inspector = Instantiate(genericComponentLoader, content);
            inspector.linkToComponent(allComponents[i]);

        }

    }

}
