﻿///zambari codes unity

using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;

public class HierarchyNode : zNode //,IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{
    public Text childCountText;
    public RectTransform mainButton;
    public Image mainButtonImage;
    public GameObject expandButton;
    public zHierarchyView hierarchyView;
    public int indentationConstant = 12;
    [Header("Filled at runtime")]
    public GameObject referencedGameObject;
    public Transform referencedTransform;
    public int depth;
    public int childCount;
    public List<HierarchyNode> childItems;
    bool isExpanded;
    public Color nonHoveredColor = new Color(1, 1, 1, 0.1f);
    public Color hoveredColor = new Color(1, 1, 1, 0.3f);

    public void Inspect()
    {
        if (referencedGameObject == null) Debug.Log("no gameobject", gameObject);
        if (hierarchyView.activeInspector != null)
        {
            hierarchyView.activeInspector.focusOn(referencedGameObject);
        }

    }
    IEnumerator checking()
    {
        yield return null;
        //childCountText.enabled=false;
        /*while (true)
        {
          if (transform.hasChanged)
            {   transform.hasChanged=false;

            }
            yield return new WaitForSeconds(0.5f);
        }*/
    }
    public void fold()
    {  
        
        Debug.Log("folding");

        //BroadcastMessage("fold");

        for (int i = 0; i < childItems.Count; i++)
        {   //childItems[i].fold();
            childItems[i].gameObject.SetActive(false);
        }
        isExpanded = false;
        setLabelToNodeName();
      //  StopCoroutine(checking());
     //   hierarchyView.setScrollStateDirty();

    }
    public void unfold()
    { Debug.Log("unfolding");

        for (int i = 0; i < childItems.Count; i++)
            childItems[i].gameObject.SetActive(true);
        isExpanded = true;
        setLabelToNodeName();
       // StartCoroutine(checking());
//        hierarchyView.setScrollStateDirty();
    }
    // public void  OnPointerEnter(PointerEventData eventData) 


    public override void setColor()
    {

        if (controller == null) controller = GetComponentInParent<zNodeController>();
        if (mainButtonImage != null && controller != null)
        {
            if (isActive)
                mainButtonImage.color = controller.activeColor;
            else
           if (isHovered) mainButtonImage.color = controller.hoveredColor;
            else mainButtonImage.color = controller.nonHoveredColor;
        }
        if (referencedGameObject != null)
            nodeShowActiveState(referencedGameObject.activeInHierarchy);

    }


    public override void OnClick()
    {
        /*   if (isDisabled) 
           {
               mainButtonImage.color = controller.nonHoveredColor*2;
               Invoke("setColor",0.2f);
               return;

           }*/
           Debug.Log("click");
        if (childItems == null)

            childItems = hierarchyView.GetSubItems(this);
       
        if (isExpanded)
            fold();
        else unfold();
    }

    public override void setLabelToNodeName()
    {
        if (childCount > 0)
        {
            expandButton.SetActive(true);
            text.text = (isExpanded ? "▼  " + nodeName : "►  " + nodeName);
        }
        else
        {
            text.text = "     " + nodeName;
            expandButton.SetActive(false);
        }
    }
    public void setDepth(int i)
    {
        depth = i;
        mainButton.sizeDelta = mainButton.sizeDelta + new Vector2(-depth * indentationConstant, 0);
        mainButton.anchoredPosition = mainButton.anchoredPosition + new Vector2(depth * indentationConstant, 0);
    }
    public void link(GameObject c, int i)
    {
        referencedGameObject = c;
        referencedTransform = c.transform;

        childCount = referencedTransform.childCount;
        nodeName = referencedGameObject.name;
        if (i > 0)
            name = "[" + i + "]" + nodeName;
        else
            name = "[   ]" + nodeName;
        if (childCount > 0)
            childCountText.text = childCount.ToString();
        else
            childCountText.enabled = false;
        Canvas canv = referencedGameObject.GetComponent<Canvas>();
        if (canv != null)
        {
            isDisabled = true;
            nodeName = nodeName + " [canvas]";
        }
        setLabelToNodeName();
        nodeShowActiveState(referencedGameObject.activeInHierarchy);
    }

    public void setGameObjectActiveState(bool active)
    {
        referencedGameObject.SetActive(active);
        nodeShowActiveState(active);
    }

    public void nodeShowActiveState(bool active) //setasatvie
    {
        if (active)
            text.color = Color.white;
        else text.color = Color.black;
    }



}
