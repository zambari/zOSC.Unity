﻿///zambari codes unity

using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;

public class HierarchyTab : MonoBehaviour {
   public  zHierarchyView hierarchypanel;
    public Button button;
    public Text text;
    public int orderingHint;
  
   public Scrollbar scrollbar;
  //  Canvas canvas;
public RectTransform maskRect;
[Header ("Filled at runtime")]
  public  GameObject content;
  public  RectTransform contentRect;
  public float scrollAmount;
    public void linkToTab(GameObject tab)
    {
        if (tab==null ) Debug.Log("null tab");
        content = tab;
        contentRect=tab.GetComponent<RectTransform>();
        
        //contentMask=tab
      }
    public GameObject getContent()
    {
        return content ;
        //contentMask=tab
      }
   public string tabName { get {return gameObject.name; } set {gameObject.name=value;}}
    public void setLabel(string n)
    {
        gameObject.name = "TAB " + n;

        text.text = n;
    }
    void Awake()
    {
//       if (settingsPanel==null) settingsPanel=GetComponentInParent<zSettings>();
        if (text==null) text=GetComponentInChildren<Text>();
        if (button==null) button=GetComponent<Button>();
      //  canvas=GetComponentInParent<Canvas>();
    }
    public void OnClick()
    {
        activatePanel();
    }
    public void activatePanel()
    {
     
      
        content.SetActive(true);
       refreshContentSize();
   
        button.interactable = false;
      
    }

public void refreshContentSize()
{
    Canvas.ForceUpdateCanvases();
   // settingsPanel.updateContentSize(contentRect.rect.height);
}
    public void deactivateTab()
    {
        content.SetActive(false);
        button.interactable = true;

   
    }

}
