﻿///zambari codes unity

using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System;

public class HierarchyInspectorLoader : MonoBehaviour
{
    public Text headerText;
    bool isVisible=true;
    protected Component component;
    string componentType;
    public FloatRangedInspector floatRangedTemplate;
    public InspectorBase transformInspectrTemplate;
    List<GameObject> myFields;
    InspectorBase loadCustomInspector(InspectorBase l)
    {
           InspectorBase thisInsp = Instantiate(l, transform.parent);
           thisInsp.transform.SetAsLastSibling();
           myFields.Add(thisInsp.gameObject);
           return thisInsp;
    }
    public virtual void linkToComponent(Component thisComponent)
    {
        if (myFields != null) Debug.Log("watch for leaks");
        myFields = new List<GameObject>();
        component = thisComponent;

        componentType = thisComponent.GetType().ToString();
        if (componentType.Contains("UnityEngine."))
            componentType=componentType.Substring(12);
        name = "Header "+componentType;
        setHeader();
        if (thisComponent.GetType()==typeof(Transform))
        {
                loadCustomInspector(transformInspectrTemplate);
                return;
        }

        myFields = new List<GameObject>();

        FieldInfo[] fields = thisComponent.GetType().GetFields();
        for (int i = 0; i < fields.Length; i++)
        {


            FieldInfo thisField = fields[i];
            if (thisField.FieldType == typeof(float))
            {
                FloatRangedInspector thisVal = Instantiate(floatRangedTemplate, transform.parent);
                thisVal.transform.SetAsLastSibling();
                thisVal.linktToField(thisComponent,thisField);
                myFields.Add(thisVal.gameObject);

            }
        }





    }
/*    public static void FindFloats(Type source, out List<FieldInfo> fieldsList, out List<string> names, out List<Vector2> range)
    {

        names = new List<string>();
        range = new List<Vector2>();
        fieldsList = new List<FieldInfo>();

        FieldInfo[] fields = source.GetFields();
        for (int i = 0; i < fields.Length; i++)
        {
            FieldInfo thisField = fields[i];
            if (thisField.FieldType == typeof(float))
            {
                names.Add(thisField.Name);
                fieldsList.Add(thisField);
                object[] thisAttr = thisField.GetCustomAttributes(typeof(RangeAttribute), true); //FieldAttributes
                Vector2 thisRange = Vector2.zero;
                foreach (object att in thisAttr)
                {
                    if (att.GetType() == typeof(RangeAttribute))
                    {

                        RangeAttribute thisRangeAttr = (RangeAttribute)att;
                        thisRange = new Vector2(thisRangeAttr.min, thisRangeAttr.max);
                    }
                }
                range.Add(thisRange);
            }

        }
    }*/
    public void fold()
    {
        for (int i=0;i<myFields.Count;i++)
        myFields[i].SetActive(false);
        isVisible = false;

    }
    public void unFold()
    {
     
        for (int i=0;i<myFields.Count;i++)
        myFields[i].SetActive(true);
        isVisible = true;

    }
    void setHeader()
    {
        headerText.text = (isVisible ? "▼ " + componentType : "►  " + componentType);
    }

    public void toggleVisibility()
    {
       if (isVisible)
        {
            fold();
        }
        else unFold();

    }

}
