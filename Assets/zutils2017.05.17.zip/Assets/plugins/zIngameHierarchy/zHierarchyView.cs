﻿///zambari codes unity

using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;

public class zHierarchyView : zNodeController
{
    public zInspector activeInspector;
    public HierarchyNode nodeTemplate;
    Dictionary<string, HierarchyTab> tabDict;
    public HierarchyTab tabButtonTemplate;
   

    #region tab
    //    HierarchyTab defaultTab;
    HierarchyTab AddTab(string tabName)
    {

        GameObject newTabButton = Instantiate(tabButtonTemplate.gameObject);
        newTabButton.SetActive(true);
        newTabButton.transform.SetParent(tabButtonTemplate.transform.parent);
        newTabButton.transform.localScale = tabButtonTemplate.transform.localScale;
        newTabButton.transform.SetAsLastSibling();
        HierarchyTab thisTab = newTabButton.GetComponent<HierarchyTab>();
        thisTab.setLabel(tabName);

        GameObject newTabContent = Instantiate(content.gameObject);
        newTabContent.SetActive(true);
        newTabContent.transform.SetParent(content.transform.parent);
        newTabContent.GetComponent<RectTransform>().anchoredPosition = new Vector3(0, 0, 0);
        newTabContent.name = "CONTENT " + tabName;
        thisTab.linkToTab(newTabContent);

        //   if (activeTab == null) thisTab.activatePanel(); else newTabContent.SetActive(false);

        tabDict.Add(tabName, thisTab);
        return thisTab;
    }
    HierarchyTab getTab(string tabName)
    {

        HierarchyTab thisTab;
        if (tabDict.ContainsKey(tabName))
        {
            tabDict.TryGetValue(tabName, out thisTab);
        }
        else
            thisTab = AddTab(tabName);

        return thisTab;
    }

    #endregion tab

    public List<HierarchyNode> GetSubItems(HierarchyNode requestingItem)
    {
        List<HierarchyNode> list = new List<HierarchyNode>();
        Transform requestedWorldParent = requestingItem.referencedTransform;
        //     Debug.Log("subitems for "+requestedWorldParent.gameObject.name+" childcount "+requestedWorldParent.childCount);
        int depth = requestingItem.depth + 1;
        int index = requestingItem.transform.GetSiblingIndex();
        for (int i = 0; i < requestedWorldParent.childCount; i++)
        {
            //    Debug.Log("creting child i for "+requestingItem.referencedGameObject.name);
            HierarchyNode newNode = createNode(requestingItem, requestedWorldParent.GetChild(i).gameObject);
            newNode.setDepth(depth);
            newNode.transform.SetSiblingIndex(index + i + 1);
            list.Add(newNode);
        }
        return list;
    }


    public HierarchyNode createNode(HierarchyNode parentitem, GameObject reference)
    {
        HierarchyNode thisItem = (HierarchyNode)AddNodeFromTemplate();
        int newDepth = 0;
        if (parentitem != null)
        {
            thisItem.transform.SetSiblingIndex(parentitem.transform.GetSiblingIndex() + 1);
            newDepth = parentitem.depth + 1;
        }
        thisItem.link(reference, newDepth);
        return thisItem;
    }


   protected override void Awake()
    {
        tabDict = new Dictionary<string, HierarchyTab>();
        base.Awake();
    }
     protected override   void Start()
    {
        GameObject[] roots = UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects();//
        for (int i = 0; i < roots.Length; i++)
            createNode(null, roots[i]);
        Canvas.ForceUpdateCanvases();
    //    handleScrollStuff();
    }


}
