﻿///zambari codes unity

using UnityEngine;
//using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;

public class ConsoleBackLog : zNodeController {
public int maxRows;
     public  void AddEntry(string text)
    {
       
        zLogRow row;
        if (nodes.Count>maxRows)
            {
                zLogRow thisRow=nodes[0] as zLogRow;
                nodes.RemoveAt(0);
                Destroy(thisRow.gameObject);
            }
            
                row=AddNodeFromTemplate() as zLogRow;
                nodes.Add(row);
               

         row.printMessage(new LogMessage(text));
         
    }
 
protected override void Awake()
{
    base.Awake();
    scrollRect.reversedScroll=false;
    
}
	
}
