﻿///zambari codes unity

using System;
using UnityEngine;
//using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;

public class zColorProvider : MonoBehaviour {


	public static zColorProvider instance;

public Color idleColor=new Color(0,0,0,0.2f);
public Color hoverColor=new Color(1,1,1,0.2f);
public Color pressColor=new Color(1,0,0,0.5f);
public Color selectedColor = new Color (0,0,1,0.3f);
public Color selectedHoverColor = new Color (0.5f,0.5f,1,0.3f);


public Color inactiveColor = new Color (0.5f,0.5f,1,0.3f);

public Action colorsChanged;

void OnValidate()
{
     if (colorsChanged!=null) colorsChanged.Invoke();

}

public bool makeThisInstanceGlobal;
    void Awake()
    {
     if (makeThisInstanceGlobal)
     if (instance==null)   instance=this; else Debug.LogWarning(name+" another color provider set to global :"+instance.name,gameObject);


    }

    public static Color getIdle() { return instance.idleColor; }
    public static Color getHover() { return instance.idleColor; }
    public static Color getPress() { return instance.idleColor; }
    public static Color getSelected() { return instance.idleColor; }
    public static Color getSelectedHover() { return instance.idleColor; }
}


