﻿using UnityEngine;
using System;
using UnityEngine.UI;
using System.Reflection;

public class FloatRangedInspector : InspectorBase
{


    //public delegate float SettingScaler(f

    public Slider slider;
    public Text valueDisplayText;

    public Action<float> valueChanged;

    public void setRange(float newMin, float newMax)
    {
        slider.minValue = newMin;
        slider.maxValue = newMax;

    }
    //public float getValue { get { return (scaler==null ? slider.value: scaler(slider.value)); }
    public float value
    {
        get { return slider.value; }
        set { slider.value = value; }
    }
    FieldInfo field;
    float halfOfRange = 0.5f;
    public InputField inputField;
    Component component;
    public override void linktToField(Component c, FieldInfo f)
    {
        field = f;
        component = c;
        object[] fieltAttributes = field.GetCustomAttributes(typeof(RangeAttribute), true); //FieldAttributes
        Vector2 thisRange = Vector2.zero;

        slider.value = (float)field.GetValue(component);
        slider.maxValue = 1 + slider.value * 2;
        for (int i = 0; i < fieltAttributes.Length; i++)
            if (fieltAttributes[i].GetType() == typeof(RangeAttribute))
            {

                RangeAttribute thisRangeAttr = (RangeAttribute)fieltAttributes[i];
                slider.minValue = thisRangeAttr.min;
                slider.maxValue = thisRangeAttr.max;
                //    range=new Vector2(thisRangeAttr.min,thisRangeAttr.max);
                break;
            }
        halfOfRange = (slider.minValue + slider.maxValue) / 2;
        text.text = field.Name;
        name = "-float" + component.GetType().ToString();

    }

    public void inputfieldChanged(string s)
    {
        Debug.Log("input field chaned" + s);
        float f = Single.Parse(s);
        sliderValueChanged(f);
        slider.value = f;
    }
    public void sliderValueChanged(float v)
    {
        if (component == null)
        {
            Debug.Log("no component"); return;
        }
        inputField.text = (Mathf.Round(v * 1000) / 1000).ToString();
        field.SetValue(component, v);

        if (v > halfOfRange)
            inputField.transform.localPosition = new Vector3(-40, 0, 0);
        else
            inputField.transform.localPosition = new Vector3(40, 0, 0);


    }


}
