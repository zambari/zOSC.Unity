﻿///zambari codes unity

using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;


[RequireComponent(typeof(Image))]
public class BinaryPreviewHelper : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    Image image;
    Text text;
    public byte b = 65;
    public int index;
 
 int showMode=1;
    public void ShowIndex()
    {
showMode=3;

    
        show();
    }
    
    public void ShowValue()
    {
        showMode=0;

        show();
    }

    
    public void ShowChar()
    {
        showMode=1;
 show();
          
    }

    void show()
    {
if (showMode==0)   text.text = b.ToString();
if (showMode==1)   text.text = ((char)b).ToString();

if (showMode==3)    text.text = (index).ToString();


    }
  public void setByte(byte bb)
    {
        b=bb;
        float f=((float)b)/255;
        image.color=new Color(f,f,f,0.5f);
        show();
    }
  public void setIndex(int i)
    {
        index =i;

    }
    void Awake()
    {
        image = GetComponent<Image>();
        text = GetComponentInChildren<Text>();
      //  EventTrigger eventTrigger = GetComponent<EventTrigger>();

    }

    public void OnPointerEnter(PointerEventData a)
    {
     if (showMode==1) 
       text.text = (b).ToString();
     else
        text.text = ((char) b).ToString();

    }
    public void OnPointerExit(PointerEventData a)
    {
      show();

    }
}
