﻿///zambari codes unity

using UnityEngine;
using UnityEngine.EventSystems;
//using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;

public class CameraPresets : MonoBehaviour
{
    int numPresets = 11;
    public bool[] isSaved;
    public Vector3[] positions;
    Quaternion[] rotations;
    float[] fovs;

    Camera cam;

    void prepareArrays()
    {
        if (cam == null) cam = GetComponent<Camera>();
        int prefssaved = PlayerPrefs.GetInt("camerasSaved");
        PlayerPrefs.SetInt("camerasSaved", 1);
        if (prefssaved == 0)
        {

            isSaved = new bool[numPresets];
            positions = new Vector3[numPresets];
            rotations = new Quaternion[numPresets];
            fovs = new float[numPresets];
            pushToPrefs();
            Debug.Log("created preferences");
        }
        else
            popFromPrefs();

    }
    void OnEnable()
    {
        prepareArrays();
    }
    void OnValidate()
    {

        prepareArrays();
        if (positions.Length < numPresets)
        {
            Debug.Log("s");
            prepareArrays();
        }
        bool[] sv = PlayerPrefsX.GetBoolArray("isSaved");
        for (int i = 0; i < numPresets; i++)
        {
            if (isSaved[i] && !sv[i]) { handleSave(i); return; }
         //   if (!isSaved[i] && sv[i]) { Debug.Log("clearing "+i);handleClear(i); return; }
        }


    }
    void popFromPrefs()
    {

        positions = PlayerPrefsX.GetVector3Array("positions");
        rotations = PlayerPrefsX.GetQuaternionArray("rotations");
        fovs = PlayerPrefsX.GetFloatArray("fovs");
        isSaved = PlayerPrefsX.GetBoolArray("isSaved");

    }

    void pushToPrefs()
    {

        PlayerPrefsX.SetBoolArray("isSaved", isSaved);
        PlayerPrefsX.SetVector3Array("positions", positions);
        PlayerPrefsX.SetQuaternionArray("rotations", rotations);
        PlayerPrefsX.SetFloatArray("fovs", fovs);


    }
 
    void handleLoad(int slot)
    {
        if (!isSaved[slot])
        {
            Debug.Log("NOT SAVED");
            return;
        }
        else Debug.Log("loading");

        cam.transform.position = positions[slot];
        cam.transform.rotation = rotations[slot];
        cam.fieldOfView = fovs[slot];


    }
    void handleSave(int slot)
    {
        Debug.Log("save slot " + slot);
        positions[slot] = cam.transform.position;
        rotations[slot] = cam.transform.rotation;
        fovs[slot] = cam.fieldOfView;
        isSaved[slot] = true;
        pushToPrefs();
        Debug.Log("saved camera position " + transform.position);


    }

    void nr(int nr)
    {

        if (Input.GetKey(KeyCode.LeftShift)) handleSave(nr); else handleLoad(nr);
    }
    void Update()
    {
         if (EventSystem.current.IsPointerOverGameObject()) return;
        if (Input.GetKeyDown("1")) nr(1);
        else 
        if (Input.GetKeyDown("2")) nr(2);
        else
        if (Input.GetKeyDown("3")) nr(3);
        else
        if (Input.GetKeyDown("4")) nr(4);
        else
        if (Input.GetKeyDown("5")) nr(5);
        else
        if (Input.GetKeyDown("6")) nr(6);
        else
        if (Input.GetKeyDown("7")) nr(7);
        else
        if (Input.GetKeyDown("8")) nr(8);
        else
        if (Input.GetKeyDown("9")) nr(9);
        else
        if (Input.GetKeyDown("0")) nr(10);

        {




        }

    }

}
