﻿///zambari codes unity

using System.Reflection;
using UnityEngine;
//using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;

public class InspectorBase : zNode {
public  virtual void linktToField(Component c,FieldInfo f)
{
    
}
public  virtual void linktToComponent(Component thisComponent) {}
	
}
