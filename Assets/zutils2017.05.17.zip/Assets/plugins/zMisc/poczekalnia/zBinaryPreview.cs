﻿///zambari codes unity

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;
[RequireComponent(typeof(GridLayoutGroup))]
public class zBinaryPreview : MonoBehaviour,IPointerClickHandler { //
BinaryPreviewHelper template;
static zBinaryPreview instance;
List<BinaryPreviewHelper> helpers;
Image image;
Color savedColor;
public bool showIncomingOsc;
void Awake()
{ 
 template=GetComponentInChildren<BinaryPreviewHelper>();
 template.gameObject.SetActive(false);
 instance=this;
    helpers=new List<BinaryPreviewHelper>();
 image=GetComponent<Image>();
 savedColor=image.color;
}
public void OnPointerClick(PointerEventData e)
{
    if (helpers.Count==0) return;
    if (e.button==PointerEventData.InputButton.Middle) BroadcastMessage("ShowIndex");
    if (e.button==PointerEventData.InputButton.Right) BroadcastMessage("ShowValue");
    if (e.button==PointerEventData.InputButton.Left) BroadcastMessage("ShowChar");
    
}

void OnValidate()
{
     if (showIncomingOsc)
    zOSC.OnOSCRecieve+=recievedOSC;
    else
    zOSC.OnOSCRecieve-=recievedOSC;
}
void Start()
{

}

void recievedOSC()
{
    display(zOSC.lastRecieved.BinaryData);

}
void restoreColor()
{
    image.color=savedColor;
}
void restoreInABit()
{
Invoke("restoreColor",0.1f);
}
public static void display(byte[] bytes)
{

instance.image.color=new Color(1,1,1,0.2f);
instance.restoreInABit();

 if (instance.helpers.Count<bytes.Length)
    for (int i=instance.helpers.Count;i<bytes.Length;i++)
    {
            BinaryPreviewHelper thisByte=Instantiate(instance.template,instance.transform);
            instance.helpers.Add(thisByte);

  
    }
      for (int i=0;i<bytes.Length;i++)

    {     BinaryPreviewHelper thisByte=instance.helpers[i];
          thisByte.gameObject.SetActive(true);
          thisByte.setByte(bytes[i]);
          thisByte.setIndex(i);


    }
  for (int i=bytes.Length;i<instance.helpers.Count;i++)

   {     BinaryPreviewHelper thisByte=instance.helpers[i];
          thisByte.gameObject.SetActive(false);


    }
           

}


	
}
