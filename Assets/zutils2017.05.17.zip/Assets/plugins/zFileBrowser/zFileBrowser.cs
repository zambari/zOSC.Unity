﻿

using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using System.IO;
using System;


public interface IOpenFiles
{
    void openFile(string s);  // implement and attach to the browser to enable opening of files
}

public class zFileBrowser : zNodeController
{
    public List<string> fileExtensionsToOpen;
    public List<string> fileExtensionsToIgnore;
    public Text pathdisplay;
    string currentPath;
    bool recievedNav;
    public override void GoParent()
    {
        scanDir(Directory.GetParent(currentPath).FullName);
    }

    protected override void scrollToActive()
    {
        base.scrollToActive();
        recievedNav = true;
    }
    public FileNode createNode(FileNode parentitem, FileNode.NodeTypes type, string path)
    {
        FileNode thisItem;
        if (type == FileNode.NodeTypes.file) thisItem = Instantiate(getTemplate("FileNode"), content) as FileNode;
        else
         if (type == FileNode.NodeTypes.directory) thisItem = Instantiate(getTemplate("DirNode"), content) as FileNode;
        else
          if (type == FileNode.NodeTypes.parent) thisItem = Instantiate(getTemplate("ParentDirNode"), content) as FileNode;
        else
            thisItem = Instantiate(getTemplate("FileInactive"), content) as FileNode;
        int newDepth = 0;
        if (parentitem != null)
        {
            thisItem.transform.SetSiblingIndex(parentitem.transform.GetSiblingIndex() + 1);
            newDepth = parentitem.depth + 1;
        }
        thisItem.gameObject.SetActive(true);
        thisItem.link(type, path, newDepth);
        nodes.Add(thisItem);
        return thisItem;
    }
    public void scanDir(string s)
    {       
     
        for (int i = content.childCount - 1; i >= 0; i--)
            Destroy(content.GetChild(i).gameObject);
        nodes = new List<zNode>();
        activeNodeIndex = 0;
         currentPath=s;
        s = s.Replace('\\', '/');
        if (!System.IO.Directory.Exists(s)) s = Application.dataPath;
        pathdisplay.text = s;
        string[] dirs = System.IO.Directory.GetDirectories(s, "*.*", System.IO.SearchOption.TopDirectoryOnly);
        string[] files = System.IO.Directory.GetFiles(s, "*.*", System.IO.SearchOption.TopDirectoryOnly); //System.IO.SearchOption.AllDirectories)
        createNode(null, FileNode.NodeTypes.parent, s);
        for (int i = 0; i < dirs.Length; i++)
            createNode(null, FileNode.NodeTypes.directory, dirs[i]);
        for (int i = 0; i < files.Length; i++)
        {
            string ext = Path.GetExtension(files[i]);
            if (!fileExtensionsToIgnore.Contains(ext))
            {
                if (fileExtensionsToOpen.Contains(ext))
                    createNode(null, FileNode.NodeTypes.file, files[i]);
                else
                    createNode(null, FileNode.NodeTypes.fileInactive, files[i]);
                //sortfiles.Add(files[i]);
            }
        }

      //      Canvas.ForceUpdateCanvases();
        if (recievedNav)
            nodes[activeNodeIndex].setAsActive(true);

    }

    protected override void Start()
    {
        base.Start();
        scanDir(Application.streamingAssetsPath);
    }

    public void childTransformChanged(int i)
    {
    }


}
