﻿
//zambari codes unity

using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using System.IO;

public class FileNode : zNode
{
  
  //  public RectTransform mainButton;
    public zFileBrowser zFileBrowser;
    public int indentationConstant = 12;
    [Header("Filled at runtime")]

    public string file;
  
    public int depth;

    public enum NodeTypes { file, directory, parent, fileInactive }
    public NodeTypes type;

    //    List<FileNode> childItems;

    public override void OnClick()
    {
        if (type == NodeTypes.fileInactive) return;
        if (type == NodeTypes.file)
        {
            IOpenFiles opener = GetComponentInParent<IOpenFiles>();
            if (opener != null) opener.openFile(file); else Debug.Log("add opener to file browser");
        }
        if (type == NodeTypes.directory)
            zFileBrowser.scanDir(file);
        if (type == NodeTypes.parent)
        {
            zFileBrowser.GoParent();

        }
    }

  
    public void link(NodeTypes t, string path, int i)
    {
      
        type = t;
        file = path;
        if (type == NodeTypes.parent)
            nodeName = "..";
        else
        {
            path = Path.GetFileName(path);
            nodeName = path;
        }
        name = "[" + nodeName + "]";
        setLabelToNodeName();
    
    if (type == NodeTypes.fileInactive)
        isDisabled=true;

    }

   
  /*/
    public void fold()
    {
        //    for (int i = 0; i < childItems.Count; i++)
        //       childItems[i].gameObject.SetActive(false);
        // isExpanded = false;
        setLabelToNodeName();
        //    zFileBrowser.childTransformChanged(-childItems.Count);
    }
    public void unfold()
    {
        //    for (int i = 0; i < childItems.Count; i++)
        //        childItems[i].gameObject.SetActive(true);
        //    isExpanded = true;
        setLabelToNodeName();

    }
   
    public void setDepth(int i)
    {
        depth = i;
        mainButton.sizeDelta = mainButton.sizeDelta + new Vector2(-depth * indentationConstant, 0);
        mainButton.anchoredPosition = mainButton.anchoredPosition + new Vector2(depth * indentationConstant, 0);
    }*/


}
