﻿///zambari codes unity

using UnityEngine;
//using UnityEngine.UI;
//using UnityEngine.UI.Extensions;
//using System.Collections;
//using System.Collections.Generic;

public class ExampleScaleSetting : MonoBehaviour {

	void Start()
    {
           SettingsSlider thisSlider =     zSettings.addSlider(gameObject.name,"Scales");
           thisSlider.setRange(0.5f, 5);
           thisSlider.valueChanged+=setScale;
           thisSlider.defValue=transform.localScale.x;
   
    }

    void setScale(float f)
    {
     transform.localScale=new Vector3(f,f,f);

    }
}
